#include "game.h"

void draw(int(*gameData)[N]);         //��ͼ
void play(int(*gameData)[N]);         //��ü�ֵ����



void draw(int(*gameData)[N])           //ҳ�����
{
    int i,j;
    cleardevice();
    PIMAGE img; //��ʼ��ͼ
	img = newimage();
	getimage(img,"img/background.png",0,0);
	putimage(0, 0, img);
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
        	int num = gameData[i][j];
            switch(num)
            {
            case 2:
            {
                getimage(img, "../img/block_2.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 4:
            {
                getimage(img, "img/block_4.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 8:
            {
                getimage(img, "img/block_8.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 16:
            {
                getimage(img, "img/block_16.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 32:
            {
                getimage(img, "img/block_32.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 64:
            {
                getimage(img, "img/block_64.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 128:
            {
                getimage(img, "img/block_128.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 256:
            {
                getimage(img, "img/block_256.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 512:
            {
                getimage(img, "img/block_512.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 1024:
            {
                getimage(img, "img/block_1024.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            case 2048:
            {
                getimage(img, "img/block_2048.png");
                putimage(j * 124, i * 124, img);
                break;
            }
            default:break;
			}
        }
    }
    delimage(img);
}


void play(int (*gameData)[N])
{
	int key;
	key = getInput();
	switch (key) {
		case UP:{
			moveUp(gameData);
			break;
		}
		case DOWN:{
			moveDown(gameData);
			break;
		}
		case LEFT:{
			moveLeft(gameData);
			break;
		}
		case RIGHT:{
			moveRight(gameData);
			break;
		}
		case EXIT:{
			exitGame();
			break;
		}
		default:
			break;
	}
	draw(gameData);
}

int  main()
{
	int gameData[N][N];
	initGame(gameData);
    initgraph(500, 500,RENDER_AUTO);//��ʼ��
	setcaption("2048");
    PIMAGE img;
    img = newimage();
    getimage(img,"img/background.png");
	putimage(0, 0, img);
	draw(gameData);
	flushkey();
    for(;is_run();){
        play(gameData);
    }

	return 0;
}
	
